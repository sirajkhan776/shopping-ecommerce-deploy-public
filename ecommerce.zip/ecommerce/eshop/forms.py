
from . models import User, product
from django import forms
from django.contrib.auth.forms import SetPasswordForm, PasswordResetForm, UserCreationForm,AuthenticationForm,UsernameField,PasswordChangeForm
from django.utils.translation import gettext,gettext_lazy as _
from django.contrib.auth import password_validation
from . models import customer 

class CustomerRegistration(UserCreationForm):
    password1 = forms.CharField(
        label= "Password",
        widget=forms.PasswordInput(attrs={'class':'form-control','placeholder':"Create password"}),
    )
    password2 = forms.CharField(
        label="Password confirmation",
        widget=forms.PasswordInput(attrs={'class':'form-control','placeholder':"Repeat password"}),
    )
    last_name = forms.CharField(required=True,label='last name',
    widget=forms.TextInput(attrs={'class':'form-control','placeholder':'last name'}))

    email = forms.CharField(required=True, label='Email',widget=forms.EmailInput
    (attrs={'class':'form-control','placeholder':"Please enter a valid email"}))
    
    # username = forms.CharField(required=True, label='username',
    # widget=forms.TextInput(attrs={'class':'form-control'}))
    
    class Meta:
        model = User
        fields=['username','first_name','last_name','email','password1','password2']
        # widgets = {'last_name':forms.TextInput(attrs={'class':'form-control'})}
        widgets = {
        'first_name':forms.TextInput(attrs={'class':'form-control','placeholder':'first name'}),
        'username':forms.TextInput(attrs={'class':'form-control','placeholder':'Username'})
        }

class UserLogin(AuthenticationForm):
    username = UsernameField(widget=forms.TextInput(attrs={"autofocus": True,'class':'form-control','placeholder':'Enter Your Username'}))
    password = forms.CharField(
        label=_("Password"),
        strip=False,
        widget=forms.PasswordInput(attrs={"autocomplete": "current-password",'class':'form-control','placeholder':"*******"}),
    )

class PasswordChange(PasswordChangeForm):
    old_password = forms.CharField(
        label=_("Old password"),
        strip=False,
        widget=forms.PasswordInput(
            attrs={"autocomplete": "current-password", "autofocus": True,'class':'form-control'}
        ),
    )

    field_order = ["old_password", "new_password1", "new_password2"]


    new_password1 = forms.CharField(
        label=_("New password"),
        strip=False,
        widget=forms.PasswordInput(
            attrs={"autocomplete": "new-password",'class':'form-control'}
        ),
        help_text=password_validation.password_validators_help_text_html(),
    )

    new_password2 = forms.CharField(
        label=_("Confirm New password"),
        strip=False,
        widget=forms.PasswordInput(
            attrs={"autocomplete": "new-password",'class':'form-control'}
        ),
        help_text=password_validation.password_validators_help_text_html()
    )

class passwordreset(PasswordResetForm):
    email = forms.EmailField(
        label=_("Email"),
        max_length=254,
        widget=forms.EmailInput(attrs={"autocomplete": "email","class":"form-control"}),
    )

class setpassword(SetPasswordForm):
    new_password1 = forms.CharField(
        label=_("New password"),
        widget=forms.PasswordInput(attrs={"autocomplete": "new-password",'class':'form-control'}),
        strip=False,
        help_text=password_validation.password_validators_help_text_html(),
    )
    new_password2 = forms.CharField(
        label=_("New password confirmation"),
        strip=False,
        widget=forms.PasswordInput(attrs={"autocomplete": "new-password",'class':'form-control'}),
    )


class profileform(forms.ModelForm):
    # profile_img = forms.ImageField(widget=forms.FileInput(attrs={'class':'form-control'}))
    class Meta:
        model = customer
        fields = ['profile_pic','name','locality','city','zipcode','state',]
        widgets = {'name':forms.TextInput(attrs={'class':'form-control'}),
        'locality':forms.TextInput(attrs={'class':'form-control'}),
        'city':forms.TextInput(attrs={'class':'form-control'}),
        'zipcode':forms.NumberInput(attrs={'class':'form-control'}),
        'profile_pic':forms.FileInput(attrs={'class':'form-control'}),
        
        }  

class   ProuductForm(forms.ModelForm):
    # user = forms.CharField(max_length=200,widget=forms.TextInput(attrs={'class':'form-control'}))
    # image = forms.ImageField(required=True,widget=forms.FileInput(attrs={'class':'form-control'}))
    # selling_price_ = forms.FloatField(required=False,label='Selling price', widget=forms.NumberInput(attrs={'class':'form-control'}))
    class Meta:
        model = product
        fields= ['product_image','product_title','discounted_price','selling_price','desc','category','product_brand','filter_price'] 
        widgets={
            'product_title':forms.TextInput(attrs={'class':'form-control'}),
            'discounted_price':forms.NumberInput(attrs={'class':'form-control'}),
            'selling_price':forms.NumberInput(attrs={'class':'form-control'}),
            'desc':forms.TextInput(attrs={'class':'form-control'}),
            # 'brand':forms.TextInput(attrs={'class':'form-control'}),
            'category': forms.Select(attrs={'class':'form-control'}),
            'filter_price':forms.Select(attrs={'class':'form-control'}),
            'product_brand': forms.Select(attrs={'class':'form-control'}),  
            'product_image': forms.FileInput(attrs={'class':'form-control'}),
        }   
