from django.contrib import admin
from .models import ProductBrand, customer, product,cart,OrderPlaced,Filter_price
# Register your models here.
@admin.register(customer)
class customerAdmin(admin.ModelAdmin):
    list_display=['id','profile_pic','name','locality','city','zipcode','state','user']

@admin.register(product)
class poductAdmin(admin.ModelAdmin):
    list_display=['id','user','product_title','selling_price','desc',
    'discounted_price','filter_price','product_brand','product_image','category']
    list_filter=['user']

@admin.register(cart)
class cartAdmin(admin.ModelAdmin):
    list_display=['id','user','product','quantity']

@admin.register(OrderPlaced)
class OrderAdmin(admin.ModelAdmin):
    list_display= ['user','product','customer','quantity','ordered_date','status']

# @admin.register(OrderPlaced)
# class OrderAdmin(admin.ModelAdmin):
#     list_display=
# admin.site.register(userprofile)
# admin.site.register(Category)

admin.site.register(Filter_price)

# admin.site.register(ProductBrand)
@admin.register(ProductBrand)
class BrandAdmin(admin.ModelAdmin):
    list_display=['id','name']


