
from django.urls import path
from eshop import views
from django.contrib.auth import views as auth_view
from . forms import PasswordChange, UserLogin,passwordreset,setpassword
# from django.urls import reverse_lazy
urlpatterns = [
    # path('', views.home),
    path('',views.homeView.as_view(),name="home"),
    path('product-detail/<int:pk>', views.product_detail, name='product-detail'),
    path('addproduct/', views.AddProduct.as_view(), name='addproduct'),
    path('add-to-cart/', views.add_to_cart, name='add-to-cart'),
    path('delete-product/<int:pk>', views.delete_product, name='deleteproduct'),
    path('update-product/<int:pk>', views.update_product, name='updateproduct'),
    path('cart/',views.show_cart,name='show_cart'),
    path('pluscart/',views.plus_Cart),
    path('minuscart/',views.minus_Cart),
    path('removecart/',views.remove_cart),
    path('buy/', views.buy_now, name='buy-now'),
    path('profile/', views.ProfileView.as_view(), name='profile'),
    path('address/', views.address, name='address'),
    path('delete/<int:pk>', views.deleteaddress, name='delete'),
    path('update/<int:pk>', views.updateaddress, name='update'),
    path('orders/', views.orders, name='orders'),
    # path('changepassword/', views.change_password, name='changepassword'),
    path('mobile/', views.mobile, name='mobile'),
    path('mobile/<slug:data>', views.mobile, name='mobiledata'),

    path('laptop/', views.laptop, name='laptop'),
    path('laptop/<slug:data>', views.laptop, name='laptopdata'),

    # path('login/', views.login, name='login'),
    path('accounts/login/',views.customlogin.as_view(),name='login'),
    path('logout/',auth_view.LogoutView.as_view(next_page='login'),name='logout'),
    path('registration/', views.customregister.as_view(), name='customerregistration'),
    
    path('passwordchange/',auth_view.PasswordChangeView.as_view(form_class=PasswordChange,
    success_url = '/passwordchangedone/',
    template_name='app/passwordchange.html'),name='passwordchange'),
    path('passwordchangedone/',auth_view.PasswordChangeDoneView.as_view(template_name='app/passwordchangedone.html'),
    name='passwordchangedone'),

    path('passwordreset/',auth_view.PasswordResetView.as_view
    (template_name='app/passwordreset.html',form_class = passwordreset ),name = 'passwordreset'),
    
    path('password-reset/done/',auth_view.PasswordResetDoneView.as_view
    (template_name='app/passwordreset_done.html'),name='password_reset_done'),

    path('password-reset-confirm/<uidb64>/<token>/',auth_view.PasswordResetConfirmView.as_view
    (template_name='app/password_reset_confirm.html',form_class = setpassword,),
    name='password_reset_confirm'),


    path('password-reset-complete/',auth_view.PasswordResetCompleteView.as_view
    (template_name='app/password_reset_complete.html'),name='password_reset_complete'),
    path('checkout/', views.checkout, name='checkout'),
    path('paymentdone/', views.paymentdone, name='paymentdone'),
]
