from taggit.managers import TaggableManager
from django.db import models
from django.contrib.auth.models import User,AbstractUser

# Create your models here.


# class Category(models.Model):
#     name = models.CharField(max_length=20)

#     def __str__(self):
#         return self.name

class ProductBrand(models.Model):
    name = models.CharField(max_length=50,null=True )
    def __str__(self):
        return self.name

class Filter_price(models.Model):
    FILTER_PRICE=(
        ('UNDER  1000','UNDER  1000'),
        ('Rs 1000 TO Rs 10000','Rs 1000 TO Rs 10,000'),
        ('Rs 10,000 TO Rs 20,000','Rs 10,000 TO Rs 20,000'),
        ('Rs 20,000 TO Rs 30,000','Rs 20,000 TO Rs 30,000'),
        ('Rs 30,000 TO Rs 40,000','Rs 30,000 TO Rs 40,000'),
        ('Rs 40,000 TO Rs 50,000','Rs 40,000 TO Rs 50,000'),
    )
    price=models.CharField(choices=FILTER_PRICE,max_length=60,default='')
    def __str__(self):
        return str(self.price)

state_choice = (("Andhra Pradesh","Andhra Pradesh"),("Arunachal Pradesh","Arunachal Pradesh"),
("Assam","Assam"),("delhi","delhi"),
("Bihar","Bihar"),("Chhattisgarh","Chhattisgarh"),("Goa","Goa"),("Gujarat","Gujarat"),
("Haryana","Haryana"),("Himachal Pradesh","Himachal Pradesh"),
("Jammu and Kashmir","Jammu and Kashmir"),("Jharkhand","Jharkhand"),("Karnataka","Karnataka"),
("Kerala","Kerala"),("Madhya Pradesh","Madhya Pradesh"),
("Maharashtra","Maharashtra"),)

class customer(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    locality = models.CharField(max_length=200)
    city = models.CharField(max_length=50)
    zipcode = models.IntegerField()
    state = models.CharField(choices=state_choice, default="delhi" ,max_length=50)
    profile_pic = models.ImageField(upload_to="profilepic",null=True)
    def __str__(self):
        return str(self.id)

category_choices = (
    ('M','Mobile'),
    ('L', 'Laptop'),
    ('TW','Top Wear'),
    ('BW','Bottom Wear'),
    ('BG','Bags'),
    ('FW','Footwears'),
    ('JW','jewellery'),
    
)

class product(models.Model):
    user = models.CharField(blank=True,max_length=100,null=True)
    # category = models.ForeignKey(Category,on_delete=models.CASCADE)
    
    product_image = models.ImageField(upload_to ="productpic",null=True)
    product_title = models.CharField( max_length=100 )
    discounted_price = models.FloatField()
    selling_price = models.FloatField(null=True,blank=True)
    desc = models.TextField(max_length=2000)
    category = models.CharField(choices=category_choices,max_length=2)
    created_at = models.DateTimeField(auto_now_add=True)
    filter_price = models.ForeignKey(Filter_price,on_delete=models.CASCADE,null=True)
    product_brand = models.ForeignKey(ProductBrand,on_delete=models.CASCADE,null=True,blank=True)
    tags = TaggableManager()

    
    # def __str__(self):
    #     return str(self.id)

class cart(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    product = models.ForeignKey(product,on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    def __str__(self):
        return str(self.id)
        
    
    @property
    def total_cost(self):
        return self.quantity * self.product.discounted_price
    
STATUS_CHOICES=(
    ('Accepted','Accepted'),
    ('Packed','Packed'),
    ('On The Way','On The Way'),
    ('Delivered','Delivered'),
    ('Cancel','Cancel'),
)
class OrderPlaced(models.Model):
    user = models.ForeignKey(User,on_delete=models.CASCADE)
    product = models.ForeignKey(product,on_delete=models.CASCADE)
    customer = models.ForeignKey(customer,on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    ordered_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=50,choices=STATUS_CHOICES,default='Pending')

    @property
    def totalcost(self):
        return self.quantity * self.product.discounted_price

# class CommentModel(models.Model):
#     comment = models.CharField(max_length=100)
#     user = models.ForeignKey(User,on_delete=models.CASCADE)
#     date = models.DateTimeField(auto_now_add=True)
#     def __str__(self):
#         return self.user.username

# class SubCommentsModel(models.Model):
#     comment = models.CharField(max_length=200)
#     user = models.ForeignKey(User,on_delete=models.CASCADE)
#     date = models.DateTimeField(auto_now_add=True)
#     sub_comment = models.ForeignKey(CommentModel,on_delete=models.CASCADE)
#     def __str__(self):
#         return self.user.username
