from datetime import datetime
from django.core.paginator import Paginator
from unicodedata import category
from django.db.models import Q
from django.http import JsonResponse
from django.shortcuts import render,redirect
from .models import ProductBrand, customer, product,cart,OrderPlaced,Filter_price
from django.views import View
from .forms import CustomerRegistration,UserLogin,PasswordChange,profileform,ProuductForm
from django.contrib import messages
from django.contrib.auth.views import LoginView
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.db.models import Min,Max



# def home(request):
#     product1 = product.objects.all()
#     return render(request, 'app/home.html',{'product':product1})

class homeView(View):
    def get(self,request):
        # mobile = product.objects.filter(category='M')
        # cmnt = CommentModel.objects.all().order_by('-id')
        all_product = product.objects.all()
        customerinfo = customer.objects.filter(user=request.user)
        laptop = product.objects.filter(category='L')
        topwears = product.objects.filter(category='TW')
        bottomwears = product.objects.filter(category='BW')
        price_filter = Filter_price.objects.all()
        brand_filter = ProductBrand.objects.all()
        price_filter_id = request.GET.get('pricefilter')
        brand_id = request.GET.get('brand')
        data = product.objects.filter(category='M')
        # if request.method=='GET':
        searchid =request.GET.get('search')
        print("searchid is",searchid)
        if searchid:
            data= product.objects.filter(product_title__istartswith=searchid)
            print("new",data)
        elif price_filter_id :
            data =product.objects.filter(filter_price=price_filter_id,category='M')
        elif brand_id:
            data =product.objects.filter(product_brand=brand_id,category='M')     
        else:
            data = product.objects.filter(category='M').order_by('discounted_price')
        return render(request,'app/home.html',{'info':customerinfo,'all_product':all_product,'data':data,'mobiles':mobile,'laptop':laptop,
        'topwears':topwears,'bottomwears':bottomwears,'pricefl':price_filter,'brand_filter':brand_filter})
    

def product_detail(request,pk):
    product1 = product.objects.get(id=pk)
    print("product is here",product1)
    item_already_cart = False
    if request.user.is_authenticated:
        item_already_cart = cart.objects.filter(Q(product=product1.id)& Q(user=request.user)).exists()
        print("already items in cart",item_already_cart)
    return render(request, 'app/productdetail.html',{'product':product1 ,'item_already_exist':item_already_cart})

@login_required
def add_to_cart(request):
    if not request.user.is_authenticated:
        return redirect('/accounts/login')
        
    else:
        user = request.user
        product_id = request.GET.get('prod_id')
        products = product.objects.get(id=product_id)
        
        print(product)
        cart(user=user,product=products).save()
        return redirect('/cart')

def show_cart(request):
    if request.user.is_authenticated:
        active_user =request.user
        carts= cart.objects.filter(user=active_user)  
        amount = 0.0
        shipping_amount = 70.0
        total_amount = 0.0
        cart_product = [p for p in cart.objects.all() if p.user==active_user]
        print("this is list",cart_product) 
        if cart_product:
            for p in cart_product:
                temp_ammount = (p.quantity * p.product.discounted_price)
                amount += temp_ammount
                total_amount = shipping_amount + amount
            return render(request,'app/addtocart.html',{'cart':carts,'total_amount':total_amount,'amount':amount})
        else:
            return render(request,'app/empty_cart.html')
    else:
        return redirect('/accounts/login')

def plus_Cart(request):
    if request.method == 'GET':
        prod_id=request.GET['prod_id']
        print("here is",prod_id)
        c = cart.objects.get(Q(product=prod_id) & Q(user=request.user))
        print("hello",c)
        c.quantity+=1
        c.save()
        amount=0.0
        shipping_amount=70.0
        cart_product=[p for p in cart.objects.all() if p.user==request.user]
        for p in cart_product:
            tempamount = (p.quantity*p.product.discounted_price)
            amount+=tempamount

        data={
            'quantity': c.quantity,
            'amount': amount,
            'totalamount':amount+shipping_amount
            }
        return JsonResponse(data)

def minus_Cart(request):
    if request.method == 'GET':
        prod_id=request.GET['prod_id']
        print("here is",prod_id)
        c = cart.objects.get(Q(product=prod_id) & Q(user=request.user))
        print("hello",c)
        c.quantity-=1
        c.save()
        amount=0.0
        shipping_amount=70.0
        cart_product=[p for p in cart.objects.all() if p.user==request.user]
        for p in cart_product:
            tempamount = (p.quantity*p.product.discounted_price)
            amount+=tempamount

        data={
            'quantity': c.quantity,
            'amount': amount,
            'totalamount':amount+shipping_amount
            }
        return JsonResponse(data)

def remove_cart(request):
    if request.method == 'GET': 
        prod_id=request.GET['prod_id']
        print("here is",prod_id)
        c = cart.objects.get(Q(product=prod_id) & Q(user=request.user))
        print("hello",c)
        c.delete()
        amount=0.0
        shipping_amount=70.0
        cart_product=[p for p in cart.objects.all() if p.user==request.user]
        for p in cart_product:
            tempamount = (p.quantity*p.product.discounted_price)
            amount+=tempamount 

        data={
            'amount': amount,
            'totalamount':amount+shipping_amount
            }
        return JsonResponse(data)

      
@ login_required
def buy_now(request):
     return render(request, 'app/buynow.html')

# def profile(request):
#  return render(request, 'app/profile.html')
@method_decorator(login_required,name='dispatch')

class ProfileView(View):
    def get(self,request):
        # if request.user.is_authenticated:
        fm= profileform()
        return render(request,'app/profile.html',{'fm':fm,'active':'btn-primary'})
            # else:
            #     return redirect('/accounts/login')

    def post(self,request):
        fm =profileform(request.POST,request.FILES)
        if fm.is_valid():
            usr = request.user
            profile_pic1 = fm.cleaned_data['profile_pic']
            # print("hey pic",profile_pic1)
            name = fm.cleaned_data['name']
            locality = fm.cleaned_data['locality']
            city = fm.cleaned_data['city']
            zipcode = fm.cleaned_data['zipcode']
            state = fm.cleaned_data['state']
            address = customer(user=usr,profile_pic=profile_pic1,name=name,locality=locality,
            city=city,zipcode=zipcode,state=state)
            address.save()
            messages.success(request,"congratulations!!! profile added successfully..")
            return redirect('/address')
        return render(request,'app/profile.html',{'fm':fm,'active':'btn-primary'})
        
@login_required
def address(request):
    # if request.user.is_authenticated:
        customerinfo = customer.objects.filter(user=request.user)
        return render(request, 'app/address.html',{'info':customerinfo,'active':'btn-primary'})
def deleteaddress(request,pk):
    cust = customer.objects.get(id=pk)
    cust.delete()
    return redirect('/address')

def updateaddress(request,pk):
    profilefm =customer.objects.get(id=pk)
    print(f"its a{profilefm} ")
    print("your profile id:",profilefm)
    form = profileform(instance=profilefm)
    if request.method == 'POST':
        form = profileform(request.POST,request.FILES,instance=profilefm)
        if form.is_valid():
            form.save()
            messages.success(request,"profile updated successfully")
            return redirect('/address')
    return render(request,'app/address_update.html',{'form':form})




    # else:
    #     return redirect('/accounts/login')


# def change_password(request):
#     pass
    # fm = PasswordChange(request.POST)
    # return render(request, 'app/changepassword.html',{'fm':fm})

def mobile(request,data=None):
    product_mob = product.objects.filter(category='M').order_by('discounted_price')
    # -----paginator-----
    # page_number = request.GET.get('page')
    # print("page number is:",page_number)
    # paginator =  Paginator(product_mob,6)
    # print("paginator is:",paginator)
    
    # page_obj = paginator.get_page(page_number)
    # print("page_obj is:",page_obj)
    brand_mobile = ProductBrand.objects.all().order_by('name')
    filter_price = Filter_price.objects.all()
    brand_id= request.GET.get('brand')
    price_filter = request.GET.get('pricefilter')
    search_id= request.GET.get("search")
    min_price = request.GET.get('min_price')
    max_price = request.GET.get('max_price')
    print("what is min and max",min_price,max_price)
    print(f"the min price is {min_price} and max price is {max_price}")
    
    # minprice = product.objects.aggregate(Min('discounted_price'))
    # maxprice = product.objects.aggregate(Max('discounted_price'))
    if min_price or max_price:
        product_mob = product.objects.filter(Q(discounted_price__gte=min_price) & Q(discounted_price__lte=max_price)).order_by('discounted_price')

    # minprice1 = product.objects.filter()
    # if min_price == '':
    #     min_price = 0
    # if max_price == '':
    #     pass
        # product_mob = product.objects.filter(discounted_price=min_price)
    # print("your minimum price is",min_price)
    elif search_id:
         product_mob=product.objects.filter(product_title__istartswith=search_id)
    elif brand_id:
        product_mob = product.objects.filter( product_brand=brand_id,category='M')
    elif price_filter:
       product_mob= product.objects.filter(filter_price=price_filter,category='M')
    elif data == 'under_1000':
        product_mob = product.objects.filter(discounted_price__lt = 1000,category='M').order_by('discounted_price')
    elif data == '1000to5000':
        product_mob = product.objects.filter(discounted_price__gte = 1000,discounted_price__lte=5001).order_by('discounted_price')
    elif data == '5000to10000':
        product_mob = product.objects.filter(discounted_price__gte = 5000,discounted_price__lte=10001)
    elif data == '10000to20000':
        product_mob = product.objects.filter(discounted_price__gte = 10000,discounted_price__lte=20001)
    elif data == 'over_20000':
        product_mob = product.objects.filter(discounted_price__gte = 20000).order_by('discounted_price')
    
    
    # if data == None:
    #     mobile = product.objects.filter(category='M')
    # elif data == 'vivo' or data == 'oppo':
    #     mobile = product.objects.filter(category='M').filter(brand=data)
    # elif data == 'below':
    #     mobile = product.objects.filter(category='M').filter(discounted_price__lt=10000)
    # elif data == 'above':
    #     gtmobile = product.objects.filter(category='M').filter(discounted_price__gt=10000)
    #     return render(request,'app/home.html',{'gt':gtmobile})
        
    return render(request, 'app/mobile.html',{'pages':product_mob,'fp':filter_price,'mob_brand':brand_mobile,'mob':product_mob,'active':'btn-primary'})

def laptop(request,data=None):
    if data == None:
        laptop = product.objects.filter(category='L')
    elif data == 'HP' or data == 'DELL':
        laptop = product.objects.filter(category='L').filter(brand=data)
    elif data == 'below':
        laptop = product.objects.filter(category='L').filter(discounted_price__lt=10000)
    elif data == 'above':
        laptop = product.objects.filter(category='L').filter(discounted_price__gt=10000)
    return render(request, 'app/laptop.html',{'lap':laptop,'active':'btn-primary'})


# <----------manually login function ---------------->
class customlogin(LoginView):
    authentication_form = UserLogin
    template_name = "app/login.html"

# def login(request):
#     if not request.user.is_authenticated:
#         form = UserLogin()
        
#     else:
#         return redirect('/profile')
#     return render(request, 'app/login.html',{'fm':form})

# <--------function base registeration ------------>
# def customerregistration(request):
#     if request.method=='POST':
#         print("helllo")
#         fm = CustomerRegistration(request.POST)
#         print("asadasd")
#         if fm.is_valid():
#             print("Asfdsdfsd")
#             fm.save()
#     fm= CustomerRegistration()
#     return render(request, 'app/customerregistration.html',{'form':fm})


# <-------------class based registration form -----------> 
class customregister(View):
    def get(self,request):
        if not request.user.is_authenticated:
             fm = CustomerRegistration()
             return render(request, 'app/customerregistration.html',{'form':fm})
        else:
            return redirect('/profile')

    def post(self,request):
        fm = CustomerRegistration(request.POST)
        if fm.is_valid():
            fm.save()
            messages.success(request,"congratulations!!! your account has been successfully created")
        return render(request, 'app/customerregistration.html',{'form':fm})

@login_required
def checkout(request):
    user = request.user
    add = customer.objects.filter(user=user)
    cart_item = cart.objects.filter(user=user)
    amount = 0.0
    shipping_ammount = 70.0
    total_amount = 0.0
    cart_product=[p for p in cart.objects.all() if p.user==request.user]
    if cart_product:
        for p in cart_product:
            tempamount = (p.quantity*p.product.discounted_price)
            amount+=tempamount
        total_amount = amount+shipping_ammount
    return render(request, 'app/checkout.html',{"add":add,"cart_item":cart_item,"totalamount":total_amount})

def paymentdone(request):
    user = request.user
    custid =  request.GET.get('custid')
    print("here is",custid)
    customer1 = customer.objects.get(id=custid)
    print(customer1)
    cart1 = cart.objects.filter(user=user)
    print("checking",cart1)
    for c in cart1:
        OrderPlaced(user=user,product=c.product,customer=customer1,quantity=c.quantity).save()
        c.delete()

    return redirect('orders')

@login_required
def orders(request):
    order=OrderPlaced.objects.filter(user=request.user)
    return render(request, 'app/orders.html',{'order':order})

@method_decorator(login_required,name='dispatch')
class AddProduct(View):
    def get(self,request):
        if request.user.is_superuser:
            print("superuser")
            addproduct=ProuductForm()
            return render(request,"app/addproduct.html",{"addproduct":addproduct})
        else:
            print("not superuser")
            return redirect('/')
    def post(self,request):
        fm=ProuductForm(request.POST,request.FILES)
        if fm.is_valid():
            # user = fm.cleaned_data['user']
            user1 =request.user
            title = fm.cleaned_data['product_title']
            dprice = fm.cleaned_data['discounted_price']
            sprice = fm.cleaned_data['selling_price']
            descr = fm.cleaned_data['desc']
            cat = fm.cleaned_data['category']
            # brnd = fm.cleaned_data['brand']
            pdimage = fm.cleaned_data['product_image']
            filterprice=fm.cleaned_data['filter_price']
            productbrand=fm.cleaned_data['product_brand']
            addproduct = product(user=user1, product_title=title,
            discounted_price=dprice,selling_price=sprice,desc=descr,
            category=cat,product_image=pdimage,filter_price=filterprice,product_brand=productbrand)
            addproduct.save()
            messages.success(request,"sucessfully added product")
            return redirect('/')
        addproduct=ProuductForm()
        return render(request,"app/addproduct.html",{"addproduct":addproduct})
        
def delete_product(request,pk):
    if request.user.is_superuser:
        print("yes")
        deletep =product.objects.get(id=pk)
        print("delete itmes",deletep)
        deletep.delete()
        return redirect('/')
    else:
        return redirect('/')

def update_product(request,pk):
    if request.user.is_superuser:
        upd =product.objects.get(id=pk)
        addproduct = ProuductForm(instance=upd)
        if request.method == 'POST':
            addproduct = ProuductForm(request.POST,request.FILES,instance=upd)
            if addproduct.is_valid():
                addproduct.save()
                messages.success(request,"product updated successfully")
    else: 
        return redirect('/')  
    return render(request,'app/addproduct.html',{'addproduct':addproduct})    
